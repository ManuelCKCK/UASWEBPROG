
<?php echo $__env->make('barbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title','mainmenu'); ?>

<style>
.circle {
  width: 200px;
  height: 200px;
  border-radius: 50%;
  position: relative;
  background-color: #84f726;
  margin: 30pt;
}

.whitebackground {
  position: absolute;
  width: 95%;
  height: 95%;
  top: 50%;
  left: 50%;
  border-radius: 50%;
  transform: translate(-50%, -50%);
  background-color: #ffffff;
}
.Text{
    font-size: 2ch;
    margin-top: 55pt;
    margin-left: 20pt;
}
</style>
<div class="d-flex flex-wrap justify-content-center">
    <div class="circle">
        <div class="whitebackground">

            <h1 class="Text" >Find and Buy Your Grocery Here!</h1>

        </div>
      </div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Downloads\Sem 5\UAS\UASWEBPROG\resources\views/mainmenu.blade.php ENDPATH**/ ?>