
<?php echo $__env->make('navbaruser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title','user'); ?>

<style>

.Text{
    font-size: 2ch;
    margin-top: 55pt;
    margin-left: 20pt;
}
.button{
  color: blue;
}
</style>
<?php if(auth()->guard()->check()): ?>

    <h1>logged in</h1>

<?php endif; ?>

<div class="d-flex flex-wrap justify-content-center">
  <?php $__currentLoopData = $itemdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="card m-4" style="width: 250px;" style="height: 150px;" style="border-radius: 50%;">
          <div class="card-body">
          <h5 class="card-title"><?php echo e($item->item_name); ?></h5>
          <img style="width: 150px;" style="height: 150px;" src="https://previews.123rf.com/images/r4yhan/r4yhan2001/r4yhan200100314/138148778-fresh-vegetables-logo-healthy-food-shop-illustration.jpg" alt="" srcset="">
          </div>
          <button type="button" style="background-color: white" class="btn btn-primary">
          <a class="button" href=<?php echo e(route('itemdetail', ['id' => $item->item_id])); ?>>Detail</a>
          </button>     
  </div>
  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div>
    <?php echo e($itemdata->links()); ?>

</div>
</div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Downloads\Sem 5\UAS\UASWEBPROG\resources\views/user.blade.php ENDPATH**/ ?>