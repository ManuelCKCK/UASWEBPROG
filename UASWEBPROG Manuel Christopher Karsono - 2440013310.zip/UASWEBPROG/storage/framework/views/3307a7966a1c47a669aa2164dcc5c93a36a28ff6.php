
<?php echo $__env->make('navbaradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title','accmain'); ?>

<?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<center>

<div class="card m-4" style="width: 250px;" style="height: 150px;" style="border-radius: 50%;">
        <div class="card-body">
        <p class="card-text">First Name : <?php echo e($acc->first_name); ?></p>
        <?php if($acc->role_id == 1): ?>
        <p>Role : User</p>
    <?php else: ?>
        <p>Role : Admin</p>
    <?php endif; ?>
        <img src="<?php echo e($acc->display_picture_link); ?>" alt="">
        <a href="" style="margin-right: 10pt">Update Role</a>
        <a href="/deleteacc/<?php echo e($acc->account_id); ?>">Delete</a>
</div>  
</div> 
</center>       
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Downloads\Sem 5\UAS\UASWEBPROG\resources\views/accmain.blade.php ENDPATH**/ ?>