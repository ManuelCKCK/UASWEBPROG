
<?php echo $__env->make('navbaruser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title','itemdetail'); ?>

<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<center>

<div class="card m-4" style="width: 250px;" style="height: 250px;" style="border-radius: 50%;">
        <div class="card-body">
            <div class="mb-2 w-80">
                <label for="email" class="form-label">Confirm Email Before purchasing</label>
                <label for="email" class="form-label">Email Address: </label>
                <input type="text" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
        <h5 class="card-title"><?php echo e($item->item_name); ?></h5>
        <p class="card-text"><?php echo e($item->item_desc); ?></p>
        <p class="card-text text-success"><?php echo e($item->price); ?></p>

</div> 
          <form method="post" action="/itemdetailbuy/<?php echo e($item->item_id); ?>">
            <?php echo csrf_field(); ?>
            <button class="btn btn-dark">Confirm Purchase</button>
        </form>
</center>       
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Downloads\Sem 5\UAS\UASWEBPROG\resources\views/buyconfirm.blade.php ENDPATH**/ ?>