
<?php echo $__env->make('navbaradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title','profileadmin'); ?>

<?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<center>

<div class="card m-4" style="width: 250px;" style="height: 250px;" style="border-radius: 50%;">
        <div class="card-body">
        <p class="card-text">First Name : <?php echo e($acc->first_name); ?></p>
        <p class="card-text">Last Name : <?php echo e($acc->last_name); ?></p>
        <p class="card-text text-success">Email : <?php echo e($acc->email); ?></p>
        <?php if($acc->gender_id == 1): ?>
            <p>Gender : Male</p>
        <?php else: ?>
            <p>Gender : Female</p>
        <?php endif; ?>
        <img src="<?php echo e($acc->display_picture_link); ?>" alt="">
        
</div>   
</center>       
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Downloads\Sem 5\UAS\UASWEBPROG\resources\views/adminprofile.blade.php ENDPATH**/ ?>