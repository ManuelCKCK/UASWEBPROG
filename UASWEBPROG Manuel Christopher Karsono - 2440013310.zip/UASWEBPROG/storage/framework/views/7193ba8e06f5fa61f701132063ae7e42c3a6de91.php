
<?php echo $__env->make('navbaruser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title','itemdetail'); ?>

<div style="padding-bottom: 150px; color:black">
    <h1 class="d-flex flex-column align-items-center pt-4" style="margin-left: -150pt">Buy</h1>
    <div class="d-flex flex-column align-items-center mt-4">
        <form action="" method="POST"  class="d-flex flex-column align-items-center">
            
            <?php echo csrf_field(); ?>
            <div class="mb-2 w-80">
                <label for="email" class="form-label">Confirm Email Address: </label>
                <input type="text" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-2 w-80">
                <label for="email" class="form-label">Vegetable Name: </label>
                <input type="text" class="form-control" name="itemname" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>

            <button type="submit" class="btn" style="background-color: rgb(228, 231, 58)">Submit</button>
        </form>
    </div>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Downloads\Sem 5\UAS\UASWEBPROG\resources\views/confirmbuy.blade.php ENDPATH**/ ?>