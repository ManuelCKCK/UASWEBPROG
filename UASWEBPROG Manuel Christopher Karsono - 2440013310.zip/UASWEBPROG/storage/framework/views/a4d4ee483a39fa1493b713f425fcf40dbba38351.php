
<?php echo $__env->make('navbaradmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title','itemdetail'); ?>

<?php $__currentLoopData = $itemdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<center>

<div class="card m-4" style="width: 250px;" style="height: 250px;" style="border-radius: 50%;">
        <div class="card-body">
        <h5 class="card-title"><?php echo e($detail->item_name); ?></h5>
        <p class="card-text">Rp. <?php echo e($detail->price); ?></p>
        <p class="card-text text-success"><?php echo e($detail->item_desc); ?></p>
        
        <button type="button" style="background-color: white" class="btn btn-primary">
        <a class="button" href="/itemdetailbuyadmin/<?php echo e($detail->item_id); ?>">Buy</a> 
        </button>  
</div>   
</center>       
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Downloads\Sem 5\UAS\UASWEBPROG\resources\views/itemdetailadmin.blade.php ENDPATH**/ ?>