
<?php echo $__env->make('navbaruser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title','itemdetail'); ?>

<?php $__currentLoopData = $buydata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<center>

<div class="card m-4" style="width: 250px;" style="height: 250px;" style="border-radius: 50%;">
        <div class="card-body">
        <h5 class="card-title"><?php echo e($buy->account_id); ?></h5>
        <p class="card-text">Rp. <?php echo e($buy->item_id); ?></p>
        <p class="card-text text-success"><?php echo e($buy->price); ?></p>
        

</div>   
</center>       
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Downloads\Sem 5\UAS\UASWEBPROG\resources\views//cart.blade.php ENDPATH**/ ?>