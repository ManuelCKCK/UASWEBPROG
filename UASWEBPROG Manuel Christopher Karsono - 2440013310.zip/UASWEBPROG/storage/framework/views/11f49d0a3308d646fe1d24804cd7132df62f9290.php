
<?php echo $__env->make('barbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title','login'); ?>
<div style="padding-bottom: 150px; color:black">
    <h1 class="d-flex flex-column align-items-center pt-4" style="margin-left: -150pt">Login</h1>
    <div class="d-flex flex-column align-items-center mt-4">
        <form action="<?php echo e(route('login')); ?>" method="POST"  class="d-flex flex-column align-items-center">
            
            <?php echo csrf_field(); ?>
            <div class="mb-2 w-80">
                <label for="email" class="form-label">Email Address: </label>
                <input type="text" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-2 w-80">
                <label for="email" class="form-label">Password: </label>
                <input type="text" class="form-control" name="password" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <?php if($errors->any()): ?>
                <p class="text-danger"><?php echo e($errors->first()); ?></p>
            <?php endif; ?>
            <div class="mb-2 w-80">
                <a href="/register">Dont have account? register now here</a>
            </div>
            <button type="submit" class="btn" style="background-color: rgb(228, 231, 58)">Submit</button>
        </form>
    </div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Downloads\Sem 5\UAS\UASWEBPROG\resources\views/login.blade.php ENDPATH**/ ?>