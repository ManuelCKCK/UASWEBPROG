<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>footer</title>
</head>
<body>
    <style>
        .footer {
          left: 0;
          bottom: 0;
          width: 100%;
          background-color: aqua;
          color: black;
          text-align: center;
        }
        </style>
        
        <div class="footer" >
          <p style="font-size: 2vh">@ Amazing E-Grocery 2023 Made by Manuel Christopher Karsono - 2440013310</p>
        </div>
</body>
</html>